// Mateusz Pawlowski. Stereoscopic 3d cube programmed in Java 2023.
// Program generates stereoscopic image of rotating cube for left and right eye.
// Using cross-eyed looking technique you can experience real 3d dimension.

package rds;

import java.math.BigDecimal;

/**
 *
 * @author M
 */
public class Point3d {

Integer x;
Integer y;
Integer z;



Integer xr;
Integer yr;
Integer zr;

Integer xr2;
Integer yr2;
Integer zr2;

Integer x2d;
Integer y2d;




Point3d(int x,int y)
{
this.x=x;
this.y=y;
this.z=z;
}
Point3d(int x,int y,int z)
{
this.x=x;
this.y=y;
this.z=z;
}

Point3d get2dPoint()
{
    int d=200;
    int x2=0;
    int y2=0;
                
                
                
                if (zr2 + d != 0) {
		
                        if (zr2 + d > 0)
                        {
                                x2 = 256 + (xr2 * d) / (zr2 + d);
                                y2 = 256 + (yr2 * d) / (zr2 + d);
                        }

			if (zr2 + d < 0)
			{
				x2 = 256 + (xr2 * d) / (-598 + (d));
				y2 = 256 + (yr2 * d) / (-598 + (d));
			}
		
                }
                else {
		    if (zr2 + d <= 0)
                    {
                            x2 = 256 + (xr2 * d) / (-598 + (d));
                            y2 = 256 + (yr2 * d) / (-598 + (d));
                    }
                }
                
    
    
    return new Point3d((int)x2,(int)y2);
}

public void moveVector(int a,int b,int c)
{

xr2=xr2+a;
yr2=yr2;
zr2=zr2;
}

public void calculate2dpoint()
{
Point3d point=this.get2dPoint();
this.x2d=point.x;
this.y2d=point.y;
}

public void rotateAxisY(double alpha)
{
        alpha = alpha * 3.14 / 180;
        
	int tx = (int)(Math.cos(alpha)*x + Math.sin(alpha)*z);
	int tz = (int)(-Math.sin(alpha)*x + Math.cos(alpha)*z);
        
        
        this.yr=y;
        this.xr=tx;
        this.zr=tz;
}

public void rotateAxisX(double alpha)
{
        alpha = alpha * 3.14 / 180;
        
	int ty = (int)(Math.cos(alpha)*yr - Math.sin(alpha)*zr);
	int tz = (int)(Math.sin(alpha)*yr + Math.cos(alpha)*zr);
        
        this.yr2=ty;
        this.zr2=tz;
        
        this.xr2=xr;
}

 
}
