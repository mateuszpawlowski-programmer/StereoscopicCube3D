// Mateusz Pawlowski. Stereoscopic 3d cube programmed in Java 2023.
// Program generates stereoscopic image of rotating cube for left and right eye.
// Using cross-eyed looking technique you can experience real 3d dimension.

package rds;

import java.awt.*;
import java.util.Random;
import javax.swing.*;
/**
 *
 * @author M
 */
public class RDS extends JPanel implements Runnable {

    /**
     * @param args the command line arguments
     */
        int sc=4;
        
        Point3d p1=new Point3d(-10*sc,-10*sc,-10*sc);
        Point3d p2=new Point3d(10*sc,-10*sc,-10*sc);
        Point3d p3=new Point3d(-10*sc,10*sc,-10*sc);
        Point3d p4=new Point3d(10*sc,10*sc,-10*sc);
        
        Point3d p5=new Point3d(-10*sc,-10*sc,10*sc);
        Point3d p6=new Point3d(10*sc,-10*sc,10*sc);
        Point3d p7=new Point3d(-10*sc,10*sc,10*sc);
        Point3d p8=new Point3d(10*sc,10*sc,10*sc);
        
        Point3d[] tab=new Point3d[]{p1,p2,p3,p4,p5,p6,p7,p8};
        
        
        Point3d p21=new Point3d(-10*sc,-10*sc,-10*sc);
        Point3d p22=new Point3d(10*sc,-10*sc,-10*sc);
        Point3d p23=new Point3d(-10*sc,10*sc,-10*sc);
        Point3d p24=new Point3d(10*sc,10*sc,-10*sc);
        
        Point3d p25=new Point3d(-10*sc,-10*sc,10*sc);
        Point3d p26=new Point3d(10*sc,-10*sc,10*sc);
        Point3d p27=new Point3d(-10*sc,10*sc,10*sc);
        Point3d p28=new Point3d(10*sc,10*sc,10*sc);
        
        Point3d[] tab2=new Point3d[]{p21,p22,p23,p24,p25,p26,p27,p28};
        
        double angle=0;
        Graphics g;
        
        public Thread thread;
        
        
        
        
    
    public RDS(){}
    
    public void run()
    {
        
        while(true){
            try{
            Thread.sleep(50);
            }catch(InterruptedException exc){return;}
           
            if (angle>=360){angle=0;} else angle=angle+1;
            
            double a=angle; 
       
        
        
            
        
            for(Point3d p:tab)
            {
                
                p.rotateAxisY(a);
                p.rotateAxisX(a);
                
                p.moveVector(18, 0, 0);
                
                p.calculate2dpoint();
            }




            for(Point3d p:tab2)
            {
            p.rotateAxisY(a);
            p.rotateAxisX(a);
            
            p.calculate2dpoint();
            }
            
            this.repaint();
            
        
        }
        
    }
      public void paintComponent(Graphics g){
        
	super.paintComponent(g);
     
        g.setColor(Color.white);
        g.fillRect(0, 0, 640, 480);
        g.setColor(Color.black);
        
        
        this.g=g;
        line(60+80+p1.x2d, p1.y2d-20, 60+80+p2.x2d, p2.y2d-20);
        line(60+80+p1.x2d, p1.y2d-20, 60+80+p3.x2d, p3.y2d-20);
        line(60+80+p3.x2d, p3.y2d-20, 60+80+p4.x2d, p4.y2d-20);
        line(60+80+p2.x2d, p2.y2d-20, 60+80+p4.x2d, p4.y2d-20);
        
        line(60+80+p5.x2d, p5.y2d-20, 60+80+p6.x2d, p6.y2d-20);
        line(60+80+p5.x2d, p5.y2d-20, 60+80+p7.x2d, p7.y2d-20);
        line(60+80+p7.x2d, p7.y2d-20, 60+80+p8.x2d, p8.y2d-20);
        line(60+80+p6.x2d, p6.y2d-20, 60+80+p8.x2d, p8.y2d-20);
        
        line(60+80+p1.x2d, p1.y2d-20, 60+80+p5.x2d, p5.y2d-20);
        line(60+80+p2.x2d, p2.y2d-20, 60+80+p6.x2d, p6.y2d-20);
        line(60+80+p3.x2d, p3.y2d-20, 60+80+p7.x2d, p7.y2d-20);
        line(60+80+p4.x2d, p4.y2d-20, 60+80+p8.x2d, p8.y2d-20);
        
        
        
        line(-100+80+p21.x2d, p21.y2d-20, -100+80+p22.x2d, p22.y2d-20);
        line(-100+80+p21.x2d, p21.y2d-20, -100+80+p23.x2d, p23.y2d-20);
        line(-100+80+p23.x2d, p23.y2d-20, -100+80+p24.x2d, p24.y2d-20);
        line(-100+80+p22.x2d, p22.y2d-20, -100+80+p24.x2d, p24.y2d-20);
        
        line(-100+80+p25.x2d, p25.y2d-20, -100+80+p26.x2d, p26.y2d-20);
        line(-100+80+p25.x2d, p25.y2d-20, -100+80+p27.x2d, p27.y2d-20);
        line(-100+80+p27.x2d, p27.y2d-20, -100+80+p28.x2d, p28.y2d-20);
        line(-100+80+p26.x2d, p26.y2d-20, -100+80+p28.x2d, p28.y2d-20);
        
        line(-100+80+p21.x2d, p21.y2d-20, -100+80+p25.x2d, p25.y2d-20);
        line(-100+80+p22.x2d, p22.y2d-20, -100+80+p26.x2d, p26.y2d-20);
        line(-100+80+p23.x2d, p23.y2d-20, -100+80+p27.x2d, p27.y2d-20);
        line(-100+80+p24.x2d, p24.y2d-20, -100+80+p28.x2d, p28.y2d-20);
        
        
        g.setColor(Color.black);
        g.setFont(new Font("System", Font.BOLD, 10));
        g.drawString("Mateusz Pawlowski. Stereoscopic 3d cube programmed in Java 2023.", 150, 400);
        g.drawString("Program generates stereoscopic image of rotating cube for left and right eye.", 150, 410);
        g.drawString("Using cross-eyed looking technique you can experience real 3d dimension.", 150, 420);
        
        
    }

    public void line(int x,int y,int x2,int y2)
    {
    g.drawLine(x, y,x2,y2);
    }
    
    public Dimension getPreferredSize(){
        return new Dimension(640, 480);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        RDS rds=new RDS();
        JPanel panel = rds;
        
        JFrame frame = new JFrame("RDS");
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
       
        
        rds.thread=new Thread(rds);
        rds.thread.start();
        
        frame.getContentPane().add(panel);
        frame.setLocation(500, 300);
        frame.pack();
        frame.show();
        
    }
    
}
